package Model;

public class ThiSinh {
    private String SBD;
    private String hoten;
    private double DiemToan;
    private double DiemLy;
    private double DiemHoa;

    public ThiSinh() {}

    public ThiSinh(String hoten,String SBD, double diemToan, double diemLy, double diemHoa) {
        this.SBD = SBD;
        this.hoten = hoten;
        DiemToan = diemToan;
        DiemLy = diemLy;
        DiemHoa = diemHoa;
    }

    public String getSBD() {
        return SBD;
    }

    public void setSBD(String SBD) {
        this.SBD = SBD;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public double getDiemToan() {
        return DiemToan;
    }

    public void setDiemToan(double diemToan) {
        DiemToan = diemToan;
    }

    public double getDiemLy() {
        return DiemLy;
    }

    public void setDiemLy(double diemLy) {
        DiemLy = diemLy;
    }

    public double getDiemHoa() {
        return DiemHoa;
    }

    public void setDiemHoa(double diemHoa) {
        DiemHoa = diemHoa;
    }

    public double TongDiem() {
        return DiemToan + DiemLy + DiemHoa;
    }

    public double DiemTB() {
        return (double) this.TongDiem() / 3;
    }
}
