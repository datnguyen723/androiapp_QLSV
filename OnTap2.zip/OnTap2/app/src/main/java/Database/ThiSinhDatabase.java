package Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import Model.ThiSinh;

public class ThiSinhDatabase extends SQLiteOpenHelper {

    public static final String HoTen="HoTen";
    public static final String SBD = "SBD";
    public static final String DToan = "DToan";
    public static final String DLy = "DLy";
    public static final String DHoa = "DHoa";
    public static final String DTB = "DTB";
    private static final String tableName = "DBTS";
    public ThiSinhDatabase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sqlCreate="Create table if not exists "+tableName+" ("
                +SBD+ " Text Primary key, "
                +HoTen+" Text, "
                +DToan+" Double, "
                +DLy+" Double, "
                +DHoa + " DOUBLE, "
                + DTB + " DOUBLE)";
        db.execSQL(sqlCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists "+tableName);
        onCreate(db);
    }

    public void addTS(ThiSinh thisinh){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(SBD,thisinh.getSBD());
        contentValues.put(HoTen,thisinh.getHoten());
        contentValues.put(DToan,thisinh.getDiemToan());
        contentValues.put(DLy,thisinh.getDiemLy());
        contentValues.put(DHoa,thisinh.getDiemHoa());
        double dtb = thisinh.DiemTB();
        contentValues.put(DTB, dtb);
        db.insert(tableName,null,contentValues);
        db.close();
    }

    public ArrayList<ThiSinh> getData(){
        ArrayList<ThiSinh> thiSinhList = new ArrayList<>();
        String sql="Select * from "+tableName;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);
        if(cursor!=null){
            while (cursor.moveToNext()){
                ThiSinh thiSinh = new ThiSinh();
                thiSinh.setSBD(cursor.getString(0));
                thiSinh.setHoten(cursor.getString(1));
                thiSinh.setDiemToan(cursor.getDouble(2));
                thiSinh.setDiemLy(cursor.getDouble(3));
                thiSinh.setDiemHoa(cursor.getDouble(4));
                thiSinhList.add(thiSinh);
            }
        }
        return thiSinhList;
    }

    public void deleteTS(String sbd){
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "Delete From " + tableName + " Where "+ SBD + "=" + sbd;
        db.execSQL(sql);
        db.close();
    }

    public void updateTS(ThiSinh thisinh) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(SBD,thisinh.getSBD());
        contentValues.put(HoTen,thisinh.getHoten());
        contentValues.put(DToan,thisinh.getDiemToan());
        contentValues.put(DLy,thisinh.getDiemLy());
        contentValues.put(DHoa,thisinh.getDiemHoa());
        double dtb = thisinh.DiemTB();
        contentValues.put(DTB, dtb);
        db.update(tableName, contentValues,SBD + "=?",
                new String[]{String.valueOf(thisinh.getSBD())});
        db.close();
    }

}
