package Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.ontap2.R;

import java.util.ArrayList;

import Model.ThiSinh;

public class ThiSinhAdapter  extends ArrayAdapter {
    Activity context;
    int IDlayout;
    ArrayList<ThiSinh> list;

    public ThiSinhAdapter(Activity context, int IDlayout, ArrayList<ThiSinh> list) {
        super(context,IDlayout,list);
        this.context = context;
        this.IDlayout = IDlayout;
        this.list = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater myflater = context.getLayoutInflater();
        convertView = myflater.inflate(IDlayout, null);

        TextView txtSBD = convertView.findViewById(R.id.txtSBD);
        TextView txtHoten = convertView.findViewById(R.id.txtHoten);
        TextView txtDTB = convertView.findViewById(R.id.txtDTB);

        ThiSinh ts = list.get(position);

        txtSBD.setText(ts.getSBD());
        txtHoten.setText(ts.getHoten());
        txtDTB.setText(ts.DiemTB()+"");

        return convertView;
    }
}
