package Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ontap2.R;

import Database.ThiSinhDatabase;
import Model.ThiSinh;

public class AddActivity extends AppCompatActivity {
    ThiSinhDatabase db = new ThiSinhDatabase(this, "Data", null, 1);;
    TextView txtAddHoten, txtAddSBD, txtAddDiemToan, txtAddDiemLy, txtAddDiemHoa;
    Button btnThem_, btnBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add);

        txtAddHoten = findViewById(R.id.txtAddHoten);
        txtAddSBD = findViewById(R.id.txtAddSBD);
        txtAddDiemToan = findViewById(R.id.txtAddDiemToan);
        txtAddDiemLy = findViewById(R.id.txtAddDiemLy);
        txtAddDiemHoa = findViewById(R.id.txtAddDiemHoa);
        btnThem_ = findViewById(R.id.btnThem_);
        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnThem_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThiSinh ts = new ThiSinh(txtAddHoten.getText().toString(),
                        txtAddSBD.getText().toString(),
                        Double.parseDouble(txtAddDiemToan.getText().toString()),
                        Double.parseDouble(txtAddDiemLy.getText().toString()),
                        Double.parseDouble(txtAddDiemHoa.getText().toString()));
                db.addTS(ts);
                setResult(110);
                finish();
            }

        });
    }
}