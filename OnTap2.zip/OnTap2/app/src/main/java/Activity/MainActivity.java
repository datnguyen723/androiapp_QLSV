package Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.QuickContactBadge;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ontap2.R;

import java.util.ArrayList;
import java.util.List;

import Adapter.ThiSinhAdapter;
import Broadcast.MyBroadcast;
import Database.ThiSinhDatabase;
import Model.ThiSinh;

public class MainActivity extends AppCompatActivity {
    ThiSinhDatabase db = new ThiSinhDatabase(this, "Data", null, 1);;
    ArrayList<ThiSinh> list = new ArrayList<>();
    ThiSinhAdapter thiSinhAdapter;
    ListView listTS;

    MyBroadcast myBroadcast;
    IntentFilter intentFilter;

    Button btnThem;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        listTS = findViewById(R.id.listTS);
        btnThem = findViewById(R.id.btnThem);

        update();

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(MainActivity.this, AddActivity.class);
                startActivityForResult(myintent,100);
            }
        });

       listTS.setOnItemClickListener(new AdapterView.OnItemClickListener() {
           @Override
           public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
               Intent myintent1 = new Intent(MainActivity.this, ThongTinActivity.class);
               myintent1.putExtra("sbd", list.get(position).getSBD().toString());
               startActivityForResult(myintent1,100);
           }
       });

        myBroadcast = new MyBroadcast();
        intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        intentFilter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(myBroadcast, intentFilter);
    }

    private void update() {
        list = new ArrayList<>();
        list = db.getData();

        for (int i=0; i<list.size(); i++) {
            for (int j=i+1; j<list.size(); j++) {
                if (list.get(i).getHoten().compareTo(list.get(j).getHoten()) > 0) {
                    ThiSinh ts = new ThiSinh();
                    ts = list.get(i);
                    list.set(i, list.get(j));
                    list.set(j, ts);
                }
            }
        }

        thiSinhAdapter = new ThiSinhAdapter(MainActivity.this,R.layout.thisinh_view, list);
        listTS.setAdapter(thiSinhAdapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100 && resultCode == 110) {
            update();
        }
    }
}