package Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ontap2.R;

import java.util.ArrayList;

import Database.ThiSinhDatabase;
import Model.ThiSinh;

public class ThongTinActivity extends AppCompatActivity {
    TextView txtSBD_tt, txtHoten_tt, txtDToan_tt, txtDLy_tt, txtDHoa_tt;
    Button btnUpdate, btnDelete, btnBack1;

    ArrayList<ThiSinh> list = new ArrayList<>();

    ThiSinhDatabase db = new ThiSinhDatabase(this, "Data", null, 1);
    Intent myintent1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_thong_tin);

        txtSBD_tt = findViewById(R.id.txtSBD_tt);
        txtHoten_tt = findViewById(R.id.txtHoten_tt);
        txtDToan_tt = findViewById(R.id.txtDToan_tt);
        txtDLy_tt = findViewById(R.id.txtDLy_tt);
        txtDHoa_tt = findViewById(R.id.txtDHoa_tt);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnBack1 = findViewById(R.id.btnBack1);

        list = db.getData();

        myintent1 = getIntent();
        String sbd = myintent1.getStringExtra("sbd");

        ThiSinh thiSinh = new ThiSinh();
        for (int i=0; i<list.size(); i++) {
            if (list.get(i).getSBD().toString().compareTo(sbd) == 0) {
                thiSinh = list.get(i);
                break;
            }
        }

        txtSBD_tt.setText(thiSinh.getSBD().toString());
        txtHoten_tt.setText(thiSinh.getHoten().toString());
        txtDToan_tt.setText(thiSinh.getDiemToan()+"");
        txtDLy_tt.setText(thiSinh.getDiemLy()+"");
        txtDHoa_tt.setText(thiSinh.getDiemHoa()+"");


        btnBack1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThiSinh ts = new ThiSinh(txtHoten_tt.getText().toString(),
                        txtSBD_tt.getText().toString(),
                        Double.parseDouble(txtDToan_tt.getText().toString()),
                        Double.parseDouble(txtDLy_tt.getText().toString()),
                        Double.parseDouble(txtDHoa_tt.getText().toString()));
                db.updateTS(ts);
                setResult(110);
                finish();
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.deleteTS(txtSBD_tt.getText().toString());
                setResult(110);
                finish();
            }
        });
    }
}